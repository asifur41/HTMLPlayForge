# HTMLPlayForge guide (simple steps)

Do one block at a time. After each block, read "You should see". If you see something else, read "If it fails".

IMPORTANT: Nobody compiled this code before you. The first build can fail. That is normal. Part 6 shows what to do.

## Part 1. Put the files in your GitHub repo

1. Open your repo in GitHub Codespaces (the repo is `asifur41/HTMLPlayForge`). If it does not exist yet, create an empty repo with that name on github.com.
2. In the Codespaces file list, upload `HTMLPlayForge.zip` (drag it in, or use the upload option in the file menu).

Now in the terminal, type this one line and press Enter:

```
unzip -o HTMLPlayForge.zip -d /tmp/hpf
```
You should see: a list of lines like `inflating: ...`.
If it fails: type `ls` and check the zip name. Then try again with the right name.

Next, one line:
```
cp -r /tmp/hpf/HTMLPlayForge/. .
```
You should see: nothing (no message is normal).
If it fails: type `ls /tmp/hpf` and tell Claude what you see.

Next, one line (the zip file must not stay in your repo):
```
rm HTMLPlayForge.zip
```
You should see: nothing.
If it fails: the zip has another name. Type `ls` and remove that file.

Next, one line:
```
bash scripts/verify_repo.sh
```
You should see: `VERIFIED: your repo is exactly what was delivered.`
If you see `DIFFERENT` or `EXTRA file`: the zip file itself and the zip you uploaded are not the same. Delete the extra things you did not make, or tell Claude.

## Part 2. Check the tools in the terminal

One line:
```
gh auth status
```
You should see: `Logged in to github.com`.
If it fails: type `gh auth login` and follow the questions.

## Part 3. Make your signing key (once, keep it forever)

The signing key proves that updates come from you. If you lose it, you cannot update the app for the people who installed it.

One line (it asks questions; when it asks for a password, type it and press Enter. You will NOT see the letters. That is normal):
```
keytool -genkeypair -v -keystore release.jks -alias htmlplayforge -keyalg RSA -keysize 2048 -validity 10000
```
Answer the questions. For "key password", press Enter (it uses the same password).
You should see: `[Storing release.jks]`.
If it fails: tell Claude the last 5 lines.

IMPORTANT: Download `release.jks` to your phone and keep a copy somewhere safe. Never put it in a chat. The file `.gitignore` stops it from being uploaded to GitHub.

## Part 4. Give GitHub the four secrets

One line (this sends the key to GitHub and prints nothing):
```
base64 -w0 release.jks | gh secret set KEYSTORE_BASE64
```
You should see: `Set Actions secret KEYSTORE_BASE64`.

One line (the alias is not secret):
```
gh secret set KEY_ALIAS --body htmlplayforge
```

One line. It asks for the value and hides what you type. Type the SAME password you used in Part 3 and press Enter:
```
gh secret set KEYSTORE_PASSWORD
```

One line. Same password again:
```
gh secret set KEY_PASSWORD
```
If any of these fails: type `gh secret list` to see which secrets exist. You need exactly these four names.

## Part 5. Build

One line:
```
bash ci.sh "first build"
```
You should see: `BUILD SUCCEEDED` after some minutes.
If you see `BUILD FAILED`: go to Part 6.

Then open your repo on github.com, click Actions, click the latest run, and download the artifact `htmlplayforge-release`. Inside is `HTMLPlayForge.apk`. Install it on your phone.

## Part 6. If the build fails
1. Copy the lines that `ci.sh` printed after `BUILD FAILED`.
2. Send them to Claude with this sentence: "HTMLPlayForge build failed. Here are the lines."
3. Claude sends you a small fix. Apply it, then run `bash ci.sh "fix"` again.

## Part 7. Publish a release (so the Settings links work)
The app links point to `https://github.com/asifur41/HTMLPlayForge/releases/latest`.

One line:
```
git tag v1.0.0
```
One line:
```
git push origin v1.0.0
```
You should see: a new run in the Actions tab. When it finishes, a release appears with four files.
The tag must equal `versionName` in `app/build.gradle.kts` (now `1.0.0`). If it is not the same, the release step stops with a clear message.

## Links to replace later
In `app/src/main/java/com/htmlplayforge/app/utils/LinkOpener.kt`:
- `COMMUNITY` (now your website)
- `REVIEW` (now your website)

## Decisions I made (you did not have to answer questions)
- The screens are built in Kotlin code, not in XML layout files. Fewer files can go wrong when nobody can compile.
- The hamburger menu is a pop-up list. The Export choice opens a second list.
- System notifications are not used. They need a permission on Android 13 and newer, and this app asks for none.
- The preview rule (CSP) allows only your own files plus data: and blob:. Inline scripts and styles are allowed, otherwise normal pages would not run. Online fonts, CDNs and images from the web do not load (there is no internet).
- Opening an outside file with the picker copies it into the project (or into a project named "Imported").
- Screenshot sharing of the preview was left out. Sharing code as text and as a PNG picture of the code is included.
- Lint messages for missing `<!DOCTYPE html>` and `<title>` appear only for pages that contain `<html>`, so small snippets are not marked.
- Fonts come from the CI download script. If a download fails, the build still works with the system monospace font.
- The launcher icon is a simple purple code symbol on a dark square (vector, no PNG files).
- Upgrade to target SDK 36 later: the root view of each screen already uses `Ui.applyInsets`. For keyboard handling add the `ime` inset there.
